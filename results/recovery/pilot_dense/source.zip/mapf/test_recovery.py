"""Independent optimality and regression checks for the recovery pipeline."""
import heapq
import itertools
import random
import unittest
import numpy as np
from mapf.grid import GridMap
from mapf.low_level import ConstraintSet, space_time_astar
from mapf.search_limits import HorizonExceeded
from mapf.conflicts import detect_all_conflicts, detect_first_conflict, count_single_agent_conflicts
from mapf.cardinal import classify_conflicts
from mapf.conflict_graph import ConflictGraph, compute_h4_and_graph
from mapf.icbs_h import ICBShSolver
from mapf.high_level_cbs import PlainCBS
from mapf.validation import validate_solution
from mapf.baselines import GuardedLearnedSelector, f_aware_residual_selector


def joint_optimum(grid, starts, goals):
    """Independent Dijkstra; finish decisions allow temporary visits to goals."""
    k = len(starts)
    initial = (tuple(starts), 0)
    best, queue = {initial: 0}, [(0, initial)]
    while queue:
        cost, state = heapq.heappop(queue)
        if best[state] != cost:
            continue
        positions, done = state
        if done == (1 << k)-1:
            return cost
        successors = [((positions, done | (1 << i)), 0) for i in range(k)
                      if positions[i] == goals[i] and not done & (1 << i)]
        moves = [[p] if done & (1 << i) else [p]+grid.get_neighbors(*p)
                 for i,p in enumerate(positions)]
        for nxt in itertools.product(*moves):
            if len(set(nxt)) != k or any(nxt[i] == positions[j] and nxt[j] == positions[i]
                                         for i in range(k) for j in range(i+1,k)):
                continue
            successors.append(((nxt, done), k-done.bit_count()))
        for nxt, step in successors:
            value = cost+step
            if value < best.get(nxt, float('inf')):
                best[nxt] = value
                heapq.heappush(queue, (value,nxt))
    return None


class RecoveryTests(unittest.TestCase):
    def test_exhaustive_two_agent_optimality(self):
        grid = GridMap(2,2)
        placements = list(itertools.permutations([(0,0),(0,1),(1,0),(1,1)],2))
        for starts in placements:
            for goals in placements:
                expected = joint_optimum(grid, starts, goals)
                for solver in (PlainCBS(grid), ICBShSolver(grid),
                               ICBShSolver(grid, enable_bypass=False)):
                    result = solver.solve(list(starts),list(goals),timeout=3)
                    self.assertEqual(result['status'],'SOLVED')
                    self.assertEqual(result['cost'],expected)
                    validate_solution(grid,starts,goals,result['paths'],result['cost'])

    def test_seeded_three_agent_and_guarded_selection(self):
        rng = random.Random(711)
        grid = GridMap(3,2)
        cells = [(r,c) for r in range(2) for c in range(3)]
        class Score:
            def predict(self, X):
                return X[:,0] - X[:,-1]
        for _ in range(60):
            starts,goals = rng.sample(cells,3),rng.sample(cells,3)
            expected = joint_optimum(grid, starts, goals)
            for selector in (None, f_aware_residual_selector, GuardedLearnedSelector(Score())):
                result = ICBShSolver(grid,conflict_selector=selector).solve(starts,goals,timeout=3)
                self.assertEqual(result['status'],'SOLVED')
                self.assertEqual(result['cost'],expected)
                validate_solution(grid,starts,goals,result['paths'],result['cost'])

    def test_late_constraints_and_explicit_horizon(self):
        grid = GridMap(2,1)
        cs = ConstraintSet(edge_constraints={(0,0,0,1,t) for t in range(1,101)})
        self.assertEqual(len(space_time_astar(grid,(0,0),(0,1),cs))-1,101)
        with self.assertRaises(HorizonExceeded):
            space_time_astar(grid,(0,0),(0,1),cs,max_timesteps=2)
        cs = ConstraintSet(edge_constraints={(0,0,0,0,50)})
        path = space_time_astar(grid,(0,0),(0,0),cs)
        self.assertEqual(len(path)-1,50)
        self.assertNotEqual(path[49],path[50])

    def test_initial_constraints_not_truncated(self):
        grid = GridMap(2,1)
        cs = ConstraintSet(vertex_constraints={(0,1,150)})
        result = ICBShSolver(grid).solve([(0,0)],[(0,1)],initial_constraints=[cs])
        self.assertEqual(result['cost'],151)
        self.assertNotEqual(result['paths'][0][150],(0,1))

    def test_initial_collisions_and_invalid_instances(self):
        paths = [[(0,0)],[(0,0)]]
        self.assertEqual(detect_first_conflict(paths).time,0)
        self.assertEqual(len(detect_all_conflicts(paths)),1)
        for cls in (PlainCBS,ICBShSolver):
            self.assertEqual(cls(GridMap(2,1)).solve([(0,0),(0,0)],[(0,0),(0,1)])['status'],'UNSOLVABLE')
            with self.assertRaises(ValueError):
                cls(GridMap(2,1)).solve([(0,0)],[])
            self.assertEqual(cls(GridMap(2,1)).solve([],[])['cost'],0)
            self.assertEqual(cls(GridMap(2,1)).solve([(0,0)],[(0,1)],timeout=0)['status'],'TIMEOUT')

    def test_subset_and_child_context_counts(self):
        grid = GridMap(3,3)
        starts=[(1,0),(1,2),(0,1)]
        goals=[(1,2),(1,0),(2,1)]
        paths=[[s,(1,1),g] for s,g in zip(starts,goals)]
        conflicts=detect_all_conflicts(paths)
        subset=classify_conflicts(grid,starts,goals,paths,[],conflicts[:1])
        for cc in subset:
            for agent,alt,count in [(cc.conflict.agent_i,cc.alt_path_i,cc.alt_total_conflicts_i),
                                    (cc.conflict.agent_j,cc.alt_path_j,cc.alt_total_conflicts_j)]:
                copied=list(paths);copied[agent]=alt
                self.assertEqual(count,len(detect_all_conflicts(copied)))
        visited=[]
        def check(node,classified,graph):
            visited.append(node.depth)
            for cc in classified:
                for agent,alt,count in [(cc.conflict.agent_i,cc.alt_path_i,cc.alt_total_conflicts_i),
                                        (cc.conflict.agent_j,cc.alt_path_j,cc.alt_total_conflicts_j)]:
                    if alt is not None:
                        copied=list(node.paths);copied[agent]=alt
                        self.assertEqual(count,len(detect_all_conflicts(copied)))
        ICBShSolver(grid,enable_bypass=False).solve(starts,goals,on_node_callback=check)
        self.assertIn(1,visited)

    def test_mvc_all_five_vertex_graphs(self):
        edges=list(itertools.combinations(range(5),2))
        for mask in range(1<<len(edges)):
            selected=[e for i,e in enumerate(edges) if mask & (1<<i)]
            expected=min(bits.bit_count() for bits in range(1<<5)
                         if all(bits & (1<<u) or bits & (1<<v) for u,v in selected))
            self.assertEqual(ConflictGraph(selected).compute_mvc(),expected)

    def test_full_and_single_agent_detection(self):
        rng=random.Random(17)
        for _ in range(100):
            paths=[[rng.choice([(0,0),(0,1),(1,0)]) for _ in range(rng.randint(1,6))] for _ in range(3)]
            for i in range(3):
                all_conflicts=detect_all_conflicts(paths)
                expected=sum(c.agent_i==i or c.agent_j==i for c in all_conflicts)
                self.assertEqual(count_single_agent_conflicts(paths,i,paths[i],max(map(len,paths))),expected)

    def test_missing_model_is_explicit(self):
        from mapf.benchmark_worker import run
        result=run(dict(instance=dict(width=2,height=1,starts=[[0,0]],goals=[[0,1]]),
                        policy='linear',seed=1,timeout_seconds=5))
        self.assertEqual(result['status'],'MODEL_UNAVAILABLE')

    def test_invalid_ranker_fails(self):
        with self.assertRaises(ValueError):
            GuardedLearnedSelector(None,top_k_guardrail=0)


if __name__ == '__main__':
    unittest.main()
